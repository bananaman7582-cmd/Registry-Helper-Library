package com.bananaman.api;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1741;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * A small helper for registering game objects (items, blocks, armor, and anything
 * else) against a vanilla {@link class_2378} without repeating the same
 * {@link class_2960} / {@link class_5321} boilerplate every time.
 *
 * <p>Every method that existed on the original version of this class keeps the exact
 * same name, parameters and return type, so existing code that uses it keeps
 * compiling unchanged. Everything else here is additive: extra overloads for the
 * common shortcuts (a plain {@link class_1792}, a block with no {@link class_1747}, a full
 * armor set, a populated creative tab, block entities, entities, sound events, and
 * particles) so you reach for this class instead of hand-rolling registration again.
 *
 * <p>Targets Fabric for Minecraft 1.21.11 on Mojang mappings (no Yarn).
 *
 * <h2>Quick start</h2>
 * <pre>{@code
 * public class ModItems {
 *     public static final RegistryHelper<Item> ITEMS = RegistryHelper.items(MOD_ID);
 *
 *     public static final Item RUBY = ITEMS.registerItem("ruby", new Item.Properties());
 *
 *     // registers a tab that auto-populates with everything ITEMS has registered
 *     public static final CreativeModeTab RUBY_TAB =
 *             ITEMS.registerCreativeTab("ruby_tab", () -> new ItemStack(RUBY));
 * }
 *
 * public class ModBlocks {
 *     public static final RegistryHelper<Block> BLOCKS = RegistryHelper.blocks(MOD_ID);
 *
 *     // registers the block AND a matching BlockItem for it
 *     public static final Block RUBY_BLOCK =
 *             BLOCKS.registerBlock("ruby_block", Block::new, BlockBehaviour.Properties.of());
 *
 *     public static final BlockEntityType<RubyBlockEntity> RUBY_BLOCK_ENTITY =
 *             BLOCKS.registerBlockEntityType("ruby_block", RubyBlockEntity::new, RUBY_BLOCK);
 * }
 *
 * public class ModArmor {
 *     private static final RegistryHelper<Item> ITEMS = RegistryHelper.items(MOD_ID);
 *
 *     // registers helmet/chestplate/leggings/boots in one call
 *     public static final RegistryHelper.ArmorSet RUBY_ARMOR =
 *             ITEMS.registerArmorSet("ruby", ModArmorMaterials.RUBY);
 * }
 *
 * public class ModEntities {
 *     public static final RegistryHelper<EntityType<?>> ENTITY_TYPES = RegistryHelper.entityTypes(MOD_ID);
 *
 *     public static final EntityType<RubyGolemEntity> RUBY_GOLEM = ENTITY_TYPES.registerEntityType(
 *             "ruby_golem",
 *             EntityType.Builder.of(RubyGolemEntity::new, MobCategory.CREATURE).sized(1.0f, 2.0f)
 *     );
 * }
 *
 * public class ModSounds {
 *     private static final RegistryHelper<SoundEvent> SOUNDS = RegistryHelper.soundEvents(MOD_ID);
 *
 *     public static final SoundEvent RUBY_CHIME = SOUNDS.registerSoundEvent("ruby_chime");
 * }
 *
 * public class ModParticles {
 *     private static final RegistryHelper<ParticleType<?>> PARTICLES = RegistryHelper.particleTypes(MOD_ID);
 *
 *     public static final SimpleParticleType RUBY_SPARKLE = PARTICLES.registerParticle("ruby_sparkle");
 * }
 * }</pre>
 *
 * @param <T> the type of the registry this instance wraps (e.g. {@code Item}, {@code Block})
 */
public class RegistryHelper<T> {

    private final class_2378<T> registry;
    private final String modId;

    private final List<class_1792> registeredItems = new ArrayList<>();
    private final List<class_2248> registeredBlocks = new ArrayList<>();

    public RegistryHelper(
            @NotNull class_2378<T> registry,
            @NotNull String modId
    ) {
        this.registry = Objects.requireNonNull(registry, "Registry cannot be null");
        this.modId = Objects.requireNonNull(modId, "Mod ID cannot be null");

        if (this.modId.isBlank()) {
            throw new IllegalArgumentException("Mod ID cannot be blank");
        }
    }

    // -----------------------------------------------------------------
    // Static factories - the two registries almost every mod needs.
    // For anything else, just use the constructor directly, e.g.
    // new RegistryHelper<>(BuiltInRegistries.SOUND_EVENT, MOD_ID)
    // -----------------------------------------------------------------

    /** A {@code RegistryHelper} bound to the item registry for {@code modId}. */
    public static RegistryHelper<class_1792> items(@NotNull String modId) {
        return new RegistryHelper<>(class_7923.field_41178, modId);
    }

    /** A {@code RegistryHelper} bound to the block registry for {@code modId}. */
    public static RegistryHelper<class_2248> blocks(@NotNull String modId) {
        return new RegistryHelper<>(class_7923.field_41175, modId);
    }

    /** A {@code RegistryHelper} bound to the block entity type registry for {@code modId}. */
    public static RegistryHelper<class_2591<?>> blockEntityTypes(@NotNull String modId) {
        return new RegistryHelper<>(class_7923.field_41181, modId);
    }

    /** A {@code RegistryHelper} bound to the entity type registry for {@code modId}. */
    public static RegistryHelper<class_1299<?>> entityTypes(@NotNull String modId) {
        return new RegistryHelper<>(class_7923.field_41177, modId);
    }

    /** A {@code RegistryHelper} bound to the sound event registry for {@code modId}. */
    public static RegistryHelper<class_3414> soundEvents(@NotNull String modId) {
        return new RegistryHelper<>(class_7923.field_41172, modId);
    }

    /** A {@code RegistryHelper} bound to the particle type registry for {@code modId}. */
    public static RegistryHelper<class_2396<?>> particleTypes(@NotNull String modId) {
        return new RegistryHelper<>(class_7923.field_41180, modId);
    }

    // -----------------------------------------------------------------
    // Generic registration - works for any registry this instance wraps
    // -----------------------------------------------------------------

    /** Registers {@code element} under {@code name} in this helper's registry. */
    public T register(String name, T element) {
        Objects.requireNonNull(element, "Element to register cannot be null");

        T registered = class_2378.method_10230(registry, id(name), element);
        track(registered);
        return registered;
    }

    // -----------------------------------------------------------------
    // Items
    // -----------------------------------------------------------------

    /** Original signature - builds the item from {@code factory}, using {@code properties} as the base. */
    public class_1792 registerItem(
            String name,
            Function<class_1792.class_1793, class_1792> factory,
            class_1792.class_1793 properties
    ) {
        class_5321<class_1792> key = itemKey(id(name));

        class_1792 item = factory.apply(properties.method_63686(key));
        class_1792 registered = class_2378.method_39197(class_7923.field_41178, key, item);
        registeredItems.add(registered);
        return registered;
    }

    /** Like {@link #registerItem(String, Function, class_1792.class_1793)}, with fresh default properties. */
    public class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory) {
        return registerItem(name, factory, new class_1792.class_1793());
    }

    /** Registers a plain {@link class_1792} - the common case for crafting materials, etc. */
    public class_1792 registerItem(String name, class_1792.class_1793 properties) {
        return registerItem(name, class_1792::new, properties);
    }

    /** Registers a plain {@link class_1792} with default properties. */
    public class_1792 registerItem(String name) {
        return registerItem(name, class_1792::new, new class_1792.class_1793());
    }

    // -----------------------------------------------------------------
    // Blocks
    // -----------------------------------------------------------------

    /**
     * Original signature - registers the block and a matching {@link class_1747} built
     * with fresh default {@link class_1792.class_1793}, exactly like before.
     */
    public class_2248 registerBlock(
            String name,
            Function<class_4970.class_2251, class_2248> factory,
            class_4970.class_2251 properties
    ) {
        return registerBlock(name, factory, properties, new class_1792.class_1793());
    }

    /** Like above, but lets you customize the properties of the generated {@link class_1747}. */
    public class_2248 registerBlock(
            String name,
            Function<class_4970.class_2251, class_2248> factory,
            class_4970.class_2251 blockProperties,
            class_1792.class_1793 itemProperties
    ) {
        return registerBlock(name, factory, blockProperties, class_1747::new, itemProperties);
    }

    /**
     * Like above, but lets you supply the {@link class_1792} yourself instead of a plain
     * {@link class_1747} - useful for signs, tall blocks, or anything that needs a
     * custom item class. {@code itemFactory} receives the already-registered block.
     */
    public class_2248 registerBlock(
            String name,
            Function<class_4970.class_2251, class_2248> factory,
            class_4970.class_2251 blockProperties,
            BiFunction<class_2248, class_1792.class_1793, class_1792> itemFactory,
            class_1792.class_1793 itemProperties
    ) {
        class_2960 resId = id(name);
        class_5321<class_2248> blockKey = blockKey(resId);
        class_5321<class_1792> itemKey = itemKey(resId);

        class_2248 block = factory.apply(blockProperties.method_63500(blockKey));
        class_2378.method_39197(class_7923.field_41175, blockKey, block);
        registeredBlocks.add(block);

        class_1792 item = itemFactory.apply(block, itemProperties.method_63686(itemKey));
        class_2378.method_39197(class_7923.field_41178, itemKey, item);
        registeredItems.add(item);

        return block;
    }

    /** Registers a block using default {@link class_4970.class_2251#method_9637()}. */
    public class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory) {
        return registerBlock(name, factory, class_4970.class_2251.method_9637());
    }

    /** Registers a block with no {@link class_1747} at all - e.g. fire, portals, technical blocks. */
    public class_2248 registerBlockWithoutItem(
            String name,
            Function<class_4970.class_2251, class_2248> factory,
            class_4970.class_2251 properties
    ) {
        class_5321<class_2248> blockKey = blockKey(id(name));

        class_2248 block = factory.apply(properties.method_63500(blockKey));
        class_2378.method_39197(class_7923.field_41175, blockKey, block);
        registeredBlocks.add(block);
        return block;
    }

    // -----------------------------------------------------------------
    // Block entities
    // -----------------------------------------------------------------

    /**
     * Registers a {@link class_2591} for {@code factory}, valid on {@code validBlocks}.
     *
     * <p>As of Minecraft 1.21.2, vanilla's own {@code BlockEntityType.Builder} and {@code
     * BlockEntityType.BlockEntitySupplier} were made private, so mods can no longer reference
     * them directly. This uses Fabric API's {@link FabricBlockEntityTypeBuilder} instead, which
     * exists specifically as a public stand-in for that vanilla builder - no access widener
     * required - and, since block entity types no longer need a datafixer {@code Type}, its
     * {@code build()} takes no arguments.
     *
     * <pre>{@code
     * public static final RegistryHelper<Block> BLOCKS = RegistryHelper.blocks(MOD_ID);
     *
     * public static final Block RUBY_FURNACE = BLOCKS.registerBlock("ruby_furnace", RubyFurnaceBlock::new);
     * public static final BlockEntityType<RubyFurnaceBlockEntity> RUBY_FURNACE_BE =
     *         BLOCKS.registerBlockEntityType("ruby_furnace", RubyFurnaceBlockEntity::new, RUBY_FURNACE);
     * }</pre>
     *
     * @param <E> the {@link class_2586} subtype being registered
     */
    public <E extends class_2586> class_2591<E> registerBlockEntityType(
            String name,
            FabricBlockEntityTypeBuilder.Factory<E> factory,
            class_2248... validBlocks
    ) {
        class_2591<E> type = FabricBlockEntityTypeBuilder.<E>create(factory, validBlocks).build();
        return class_2378.method_10230(class_7923.field_41181, id(name), type);
    }

    // -----------------------------------------------------------------
    // Entities
    // -----------------------------------------------------------------

    /**
     * Builds and registers an {@link class_1299} from {@code builder}.
     *
     * <p>Unlike items and blocks, an entity type's builder needs its {@link class_5321} up
     * front - the key gets baked into the type for things like network tracking - so this
     * takes the (mostly configured) builder itself, rather than a bare factory, and calls
     * {@code build(...)} on it for you.
     *
     * <pre>{@code
     * public static final RegistryHelper<EntityType<?>> ENTITY_TYPES = RegistryHelper.entityTypes(MOD_ID);
     *
     * public static final EntityType<RubyGolemEntity> RUBY_GOLEM = ENTITY_TYPES.registerEntityType(
     *         "ruby_golem",
     *         EntityType.Builder.of(RubyGolemEntity::new, MobCategory.CREATURE).sized(1.0f, 2.0f)
     * );
     * }</pre>
     *
     * @param <E> the {@link class_1297} subtype being registered
     */
    public <E extends class_1297> class_1299<E> registerEntityType(String name, class_1299.class_1300<E> builder) {
        class_5321<class_1299<?>> key = entityTypeKey(id(name));
        return class_2378.method_39197(class_7923.field_41177, key, builder.method_5905(key));
    }

    // -----------------------------------------------------------------
    // Sound events
    // -----------------------------------------------------------------

    /** Registers a normal, distance-attenuated {@link class_3414} - what almost every sound in the game uses. */
    public class_3414 registerSoundEvent(String name) {
        class_2960 resId = id(name);
        return class_2378.method_10230(class_7923.field_41172, resId, class_3414.method_47908(resId));
    }

    /**
     * Registers a {@link class_3414} that doesn't attenuate with distance past {@code range}
     * blocks - useful for UI sounds, ambience, etc. The engine caps {@code range} at 16
     * regardless of what's passed in.
     */
    public class_3414 registerSoundEvent(String name, float range) {
        class_2960 resId = id(name);
        return class_2378.method_10230(class_7923.field_41172, resId, class_3414.method_47909(resId, range));
    }

    // -----------------------------------------------------------------
    // Particles
    // -----------------------------------------------------------------

    /** Registers a {@link class_2400} with no parameters - what most vanilla particles use. */
    public class_2400 registerParticle(String name) {
        return registerParticle(name, false);
    }

    /**
     * Like {@link #registerParticle(String)}, but lets you set {@code alwaysShow} - whether
     * this particle still spawns when the Particles video setting is set to Minimal. Vanilla
     * sets this {@code true} for things like explosions, campfire smoke, and squid ink.
     */
    public class_2400 registerParticle(String name, boolean alwaysShow) {
        class_2400 particle = FabricParticleTypes.simple(alwaysShow);
        return class_2378.method_10230(class_7923.field_41180, id(name), particle);
    }

    // -----------------------------------------------------------------
    // Armor
    // -----------------------------------------------------------------

    /** Original signature - registers a single armor piece with default {@link class_1792.class_1793}. */
    public class_1792 registerArmor(String name, class_1741 material, class_8051 type) {
        return registerArmor(name, material, type, new class_1792.class_1793());
    }

    /** Like above, but lets you start from your own {@link class_1792.class_1793} (durability, rarity, etc.). */
    public class_1792 registerArmor(
            String name,
            class_1741 material,
            class_8051 type,
            class_1792.class_1793 properties
    ) {
        class_5321<class_1792> key = itemKey(id(name));

        class_1792 item = new class_1792(properties.method_63686(key).method_66332(material, type));
        class_1792 registered = class_2378.method_39197(class_7923.field_41178, key, item);
        registeredItems.add(registered);
        return registered;
    }

    /**
     * Registers a full set of armor - {@code baseName + "_helmet"}, {@code "_chestplate"},
     * {@code "_leggings"} and {@code "_boots"} - in one call.
     */
    public ArmorSet registerArmorSet(String baseName, class_1741 material) {
        return registerArmorSet(baseName, material, class_1792.class_1793::new);
    }

    /** Like above, with a supplier for the base {@link class_1792.class_1793} of every piece. */
    public ArmorSet registerArmorSet(
            String baseName,
            class_1741 material,
            Supplier<class_1792.class_1793> properties
    ) {
        class_1792 helmet = registerArmor(baseName + "_helmet", material, class_8051.field_41934, properties.get());
        class_1792 chestplate = registerArmor(baseName + "_chestplate", material, class_8051.field_41935, properties.get());
        class_1792 leggings = registerArmor(baseName + "_leggings", material, class_8051.field_41936, properties.get());
        class_1792 boots = registerArmor(baseName + "_boots", material, class_8051.field_41937, properties.get());
        return new ArmorSet(helmet, chestplate, leggings, boots);
    }

    /** The four pieces produced by {@link #registerArmorSet}. */
    public record ArmorSet(class_1792 helmet, class_1792 chestplate, class_1792 leggings, class_1792 boots) {
        public List<class_1792> asList() {
            return List.of(helmet, chestplate, leggings, boots);
        }
    }

    // -----------------------------------------------------------------
    // Creative tabs
    // -----------------------------------------------------------------

    /**
     * Builds and registers a {@link class_1761} that displays every {@link class_1792} this
     * helper has registered - plain items, block items, and armor pieces alike - by reading
     * {@link #getRegisteredItems()}.
     *
     * <p>The display callback reads that list lazily, at populate-time rather than
     * registration-time, so it's fine to call this before you've registered everything else -
     * items registered afterwards still show up.
     *
     * <pre>{@code
     * public static final RegistryHelper<Item> ITEMS = RegistryHelper.items(MOD_ID);
     * // ... register items, blocks, armor via ITEMS/BLOCKS as usual ...
     *
     * public static final CreativeModeTab RUBY_TAB =
     *         ITEMS.registerCreativeTab("ruby_tab", () -> new ItemStack(RUBY));
     * }</pre>
     */
    public class_1761 registerCreativeTab(String name, Supplier<class_1799> icon) {
        return registerCreativeTab(name, icon, builder -> {});
    }

    /**
     * Like {@link #registerCreativeTab(String, Supplier)}, but hands you the underlying
     * {@link class_1761.class_7913} so you can customize it further - reorder entries with
     * your own {@code displayItems}, enable a search bar, etc. - before this helper's "show
     * everything registered" default is applied. {@code customizer} runs last, so it can
     * override any of the defaults set here.
     */
    public class_1761 registerCreativeTab(
            String name,
            Supplier<class_1799> icon,
            Consumer<class_1761.class_7913> customizer
    ) {
        class_5321<class_1761> key = creativeTabKey(id(name));

        class_1761.class_7913 builder = FabricItemGroup.builder()
                .method_47321(class_2561.method_43471("itemGroup." + modId + "." + name))
                .method_47320(icon)
                .method_47317((parameters, output) -> registeredItems.forEach(output::method_45421));

        customizer.accept(builder);

        return class_2378.method_39197(class_7923.field_44687, key, builder.method_47324());
    }

    // -----------------------------------------------------------------
    // Bookkeeping - handy for populating a creative tab, etc.
    // -----------------------------------------------------------------

    /** Every {@link class_1792} registered through this instance (plain items, block items, armor). */
    public List<class_1792> getRegisteredItems() {
        return List.copyOf(registeredItems);
    }

    /** Every {@link class_2248} registered through this instance. */
    public List<class_2248> getRegisteredBlocks() {
        return List.copyOf(registeredBlocks);
    }

    public String getModId() {
        return modId;
    }

    public class_2378<T> getRegistry() {
        return registry;
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private class_2960 id(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException(
                    "Registration name cannot be null or blank (mod id: '" + modId + "')"
            );
        }
        return class_2960.method_60655(modId, name);
    }

    private class_5321<class_1792> itemKey(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41197, id);
    }

    private class_5321<class_2248> blockKey(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41254, id);
    }

    private class_5321<class_1299<?>> entityTypeKey(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41266, id);
    }

    private class_5321<class_1761> creativeTabKey(class_2960 id) {
        return class_5321.method_29179(class_7924.field_44688, id);
    }

    private void track(T element) {
        if (element instanceof class_1792 item) {
            registeredItems.add(item);
        } else if (element instanceof class_2248 block) {
            registeredBlocks.add(block);
        }
    }
}